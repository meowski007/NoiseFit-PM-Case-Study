# NoiseFit PM — Synthetic SQL Analytics

## Purpose
A portfolio SQL project supporting the NoiseFit Sync Center product case study.

## Important
All data in this folder is **synthetic** and created solely for portfolio demonstration.
It is NOT Noise internal data and should never be presented as actual Noise product analytics.

## Business questions
1. How often do sync events fail or partially fail?
2. Which device models show higher rates of sync problems?
3. What are the most common failure reasons?
4. How long do successful syncs take?
5. Which users experience repeated sync problems?
6. How much support volume is related to sync/connectivity?
7. Is app engagement different between users with and without sync problems?
8. How much is the proposed Sync Center being used?
9. Do support patterns vary by platform?
10. How does workout engagement compare across sync-problem cohorts?

## Tech
- SQLite
- SQL
- Python/Pandas for synthetic data generation and validation

## PM connection
The analysis is designed to demonstrate how a PM could connect product telemetry to:
- reliability diagnosis
- user-impact measurement
- prioritization
- experiment design
- post-launch monitoring

## Files
- `noisefit_synthetic.db` — SQLite database
- `analysis_queries.sql` — analysis queries
- CSV files — table exports
